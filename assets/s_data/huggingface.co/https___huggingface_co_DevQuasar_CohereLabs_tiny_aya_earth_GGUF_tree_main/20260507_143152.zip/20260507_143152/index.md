# Visited: https://huggingface.co/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/tree/main
**Time:** Thu May  7 14:32:00 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (2 files)
## Downloaded Media Files

![o_HhUnXb_PgyYlqJ6gfEO.png](./media/o_HhUnXb_PgyYlqJ6gfEO.png)
![os24VYiNCoyth9yQSdv_A.jpeg](./media/os24VYiNCoyth9yQSdv_A.jpeg)

## Other Links
- [/](/)
- [/DevQuasar](/DevQuasar)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/.gitattributes](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/.gitattributes)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q2_K.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q2_K.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_L.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_L.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_M.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_M.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_S.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q3_K_S.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q4_K_M.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q4_K_M.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q4_K_S.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q4_K_S.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q5_K_M.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q5_K_M.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q5_K_S.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q5_K_S.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q6_K.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q6_K.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q8_0.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.Q8_0.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.f16.gguf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/CohereLabs.tiny-aya-earth.f16.gguf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/README.md](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/blob/main/README.md)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/colab](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/colab)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/205a898223d6dcde806b6e17ee05c853ea96732b](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/205a898223d6dcde806b6e17ee05c853ea96732b)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/3ad4425f7a790e4a8e6bb2d34f5377d31945f01b](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/3ad4425f7a790e4a8e6bb2d34f5377d31945f01b)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/6e2f05b35dd030c8cf0ea1ef5dfa7a060dee6ddf](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/6e2f05b35dd030c8cf0ea1ef5dfa7a060dee6ddf)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/7d5a90490a4f09ca20d5296c806a1934038643f7](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/7d5a90490a4f09ca20d5296c806a1934038643f7)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/864f5a00394eb573858c6e07c0906fd4034386ea](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/864f5a00394eb573858c6e07c0906fd4034386ea)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/9040bea2a12feb396dbe2d5a0fd61f258890e065](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/9040bea2a12feb396dbe2d5a0fd61f258890e065)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/9c61b2483e3a72e90efd3852ced6276b87a5ab9f](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/9c61b2483e3a72e90efd3852ced6276b87a5ab9f)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/a51bf489ec8dfdbcfc93dae77fa48e1d589c1600](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/a51bf489ec8dfdbcfc93dae77fa48e1d589c1600)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/b16de23080794cb457722c7bd17a8696f6ce185b](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/b16de23080794cb457722c7bd17a8696f6ce185b)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/bf23d8e4a87727b8219e200e3d4903848170a8fe](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/bf23d8e4a87727b8219e200e3d4903848170a8fe)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/c6a33ab067b6fc8552b3353f76a62636649aa1c5](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/c6a33ab067b6fc8552b3353f76a62636649aa1c5)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/efc1ab3023cd16807c23b9068e7a5a1624fc7de3](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commit/efc1ab3023cd16807c23b9068e7a5a1624fc7de3)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commits/main](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/commits/main)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/discussions](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/discussions)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/kaggle](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/kaggle)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/.gitattributes?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/.gitattributes?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q2_K.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q2_K.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_L.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_L.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_M.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_M.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_S.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q3_K_S.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q4_K_M.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q4_K_M.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q4_K_S.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q4_K_S.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q5_K_M.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q5_K_M.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q5_K_S.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q5_K_S.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q6_K.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q6_K.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q8_0.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.Q8_0.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.f16.gguf?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/CohereLabs.tiny-aya-earth.f16.gguf?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/README.md?download=true](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/resolve/main/README.md?download=true)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/tree/main](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF/tree/main)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?library=llama-cpp-python](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?library=llama-cpp-python)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=docker-model-runner](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=docker-model-runner)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=lemonade](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=lemonade)
- [/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=llama.cpp](/DevQuasar/CohereLabs.tiny-aya-earth-GGUF?local-app=llama.cpp)

## Stats
- Links: 80
- Media: 2
